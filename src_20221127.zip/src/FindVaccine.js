import "./App.css";

import React, { useState, useCallback } from "react";
import "survey-core/defaultV2.min.css";
import { StylesManager, Model } from "survey-core";
import { Survey } from "survey-react-ui";
import "bootstrap/dist/css/bootstrap.min.css";
import Papa from "papaparse";
import { redirect, useNavigate } from "react-router-dom";

StylesManager.applyTheme("defaultV2");

const surveyJson = {
  elements: [
    {
      name: "zipcode",
      title: "Enter your zipcode:",
      type: "text",
    },
    {
      type: "radiogroup",
      name: "service",
      title: "What are you looking for?",
      isRequired: true,
      showNoneItem: false,
      colCount: 1,
      choices: ["Vaccine", "Rapid Testing", "Hospitals"],
    },
    {
      type: "radiogroup",
      name: "vaccine",
      title: "What vaccine are you looking for?",
      visibleIf: "{service} = 'Vaccine'",
      colCount: 1,
      choices: [
        "Moderna",
        "Pfizer BioTech",
        "Jansenn",
        "Novavax",
        "Moderna Bivalent Booster",
        "Pfizer BioTech Bivalent Booster",
      ],
    },
    {
      type: "radiogroup",
      name: "rapid",
      title: "What testing are you looking for?",
      visibleIf: "{service} = 'Rapid Testing'",
      colCount: 1,
      choices: ["Express PCR Test", "Mobile Test to Treat"],
    },
    // ],
    // "completedHtmlOnCondition": [
    //   {
    //     "expression": "{service} = 'Vaccine'",
    //     "html": "<meta http-equiv='Refresh' content='0; url=https://github.com/leonakwong/Covid/actions/new' />"
    //   }, {
    //     "expression": "{service} = 'Rapid Testing'",
    //     "html": "<meta http-equiv='Refresh' content='0; url=http://localhost:3000/App.js' />"
    //   }
  ],
};

// const survey = new Model(surveyJson);
// const serviceType = survey.getQuestionByName("service");
// console.log(serviceType.value);

function FindVaccine() {
  const [data, setData] = React.useState(null);
  const navigate = useNavigate();

  React.useEffect(() => {
    fetch("/api")
      .then((res) => res.json())
      .then((data) => setData(data.express));
  }, []);

  const survey = new Model(surveyJson);
  survey.focusFirstQuestionAutomatic = false;

  const alertResults = useCallback((sender) => {
    const results = JSON.stringify(sender.data);
    switch (sender.data.service) {
      case "Vaccine":
        survey.onComplete.add(function (survey) {
          window.location.href =
            "https://github.com/leonakwong/Covid/actions/new";
        });
        break;
      case "Rapid Testing":
        navigate("/Map/" + sender.data.zipcode);
        break;
      default:
      // code block
    }

    Papa.parse(
      "https://raw.githubusercontent.com/nychealth/coronavirus-data/master/latest/last7days-by-modzcta.csv",
      {
        download: true,
        header: true,
        complete: function (results) {
          console.log(results);
        },
      }
    );
  }, []);

  survey.onComplete.add(alertResults);

  return (
    <>
      <div>
        <p>{!data ? "Loading..." : data}</p>
      </div>
      <Survey model={survey} />
    </>
  );
}

export default FindVaccine;
