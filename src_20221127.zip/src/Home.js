import React from "react";

function Home() {
  return (
    <div>
      <br />
      <h1>Welcome.</h1>
    </div>
  );
}

export default Home;
